package edyoda.assignment.LCM;

import java.util.Scanner;

public class Application {

    public static void findLCM(int a, int b, int c){
        int lcm ;
        if(a>b){
            if(a>c) lcm = a;
            else lcm=c;
        }
        else{
            if(b>c) lcm = b;
            else lcm = b;
        }

        while(true) {
            if( lcm % a == 0 && lcm % b == 0 && lcm % c == 0) {
                System.out.printf("The LCM is:" +lcm);
                break;
            }
            ++lcm;
        }
    }


    public static void main(String[] args) throws RuntimeException{
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter input : ");
        int a = sc.nextInt();
        System.out.print("Enter input : ");
        int b = sc.nextInt();
        System.out.print("Enter input : ");
        int c = sc.nextInt();
        if(a < 0 || b< 0 || c<0)
            throw new RuntimeException("Input cannot be a Negative Number");
        else findLCM(a,b,c);
    }
}

