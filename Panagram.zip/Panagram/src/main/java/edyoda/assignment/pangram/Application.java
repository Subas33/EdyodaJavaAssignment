package edyoda.assignment.pangram;

import java.util.Scanner;

public class Application {

    static boolean isLetter(char ch)
    {
        if (!Character.isLetter(ch))
            return false;

        return true;
    }

    public boolean checkPangram(String str, int len){

                int size = 26;
                str = str.toLowerCase();

                boolean[] present = new boolean[size];

                for (int i = 0; i < len; i++) {


                    if (isLetter(str.charAt(i))) {

                        int letter = str.charAt(i) - 'a';
                        present[letter] = true;
                    }
                }

                for (int i = 0; i < size; i++) {

                    if (!present[i])
                        return false;
                }
                return true;
        }



    public static void main(String[] args) throws RuntimeException{
        Scanner sc = new Scanner(System.in);
        Application app = new Application();
        System.out.print("Enter input : ");
        String input = sc.next();

        if(input.length()==0){
            throw new RuntimeException("Input cannot Empty");
        }
        else if(input.length()>=26){
            if(app.checkPangram(input, input.length())) System.out.println("Congrats!! the given String is Panagram");
        }
        else throw new RuntimeException("Input String is not a Pangram");
    }
}


