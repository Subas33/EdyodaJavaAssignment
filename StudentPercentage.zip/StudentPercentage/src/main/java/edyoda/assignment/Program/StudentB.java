package edyoda.assignment.Program;

import edyoda.assignment.Abstract.Marks;

public class StudentB extends Marks {

    public int subjectOne;
    public int subjectTwo;
    public int subjectThree;
    public int subjectFour;

    public StudentB(int subjectOne, int subjectTwo, int subjectThree,int subjectFour){
        this.subjectOne = subjectOne;
        this.subjectTwo = subjectTwo;
        this.subjectThree = subjectThree;
        this.subjectFour = subjectFour;
    }

    public double getPercentage(){
        int total = subjectOne+subjectTwo+subjectThree+subjectFour;
        double actualTotal = 400;
        double percentage = (total/actualTotal)*100;
        return percentage;
    }
}
