package edyoda.assignment.Program;

import edyoda.assignment.Abstract.Marks;

public class StudentA extends Marks {

    public int subjectOne;
    public int subjectTwo;
    public int subjectThree;

    public StudentA(int subjectOne, int subjectTwo, int subjectThree){
        this.subjectOne = subjectOne;
        this.subjectTwo = subjectTwo;
        this.subjectThree = subjectThree;
    }

    public double getPercentage(){
        double total = subjectOne+subjectTwo+subjectThree;
        double actualTotal = 300;
        double percentage = (total/actualTotal)*100;
        return percentage;
    }
}
