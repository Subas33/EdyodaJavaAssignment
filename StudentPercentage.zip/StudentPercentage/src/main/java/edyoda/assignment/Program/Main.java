package edyoda.assignment.Program;

public class Main {
    public static void main(String[] args) {
        StudentA A = new StudentA(98,98,98);
        StudentB B = new StudentB(98,98,98,90);
        System.out.println("The Percentage of StudentA is : "+A.getPercentage());
        System.out.println("The Percentage of StudentB is : "+B.getPercentage());
    }
}
