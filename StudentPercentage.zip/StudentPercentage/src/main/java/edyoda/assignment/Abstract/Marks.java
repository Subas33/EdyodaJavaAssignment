package edyoda.assignment.Abstract;

public abstract class Marks {
    public abstract double getPercentage();
}
