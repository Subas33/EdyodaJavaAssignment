package edyoda.assignment.program;

import edyoda.assignment.types.DeepCopy;
import edyoda.assignment.types.ShallowCopy;

public class MainProgram {

    public static void main(String[] args) throws CloneNotSupportedException{
        DeepCopy deep = new DeepCopy(2,5);
        ShallowCopy shallow = new ShallowCopy(3,6);

        ShallowCopy shallowClone = (ShallowCopy)shallow.clone();
        DeepCopy deepClone = (DeepCopy)deep.clone();
        shallowClone.showData();
        deepClone.showData();
    }
}
