package edyoda.assignment.types;

public class ShallowCopy implements Cloneable {

    int a;
    int b;


    ShallowCopy(){
    }

    public ShallowCopy(int a,int b){
        this.a= a;
        this.b=b;
    }
    public Object clone() throws CloneNotSupportedException{
            return super.clone();
    }

    public void showData(){
        System.out.println("From Shallow Copy : "+a +","+ b);
    }
}
