package edyoda.assignment.types;



public class DeepCopy implements Cloneable {

    int a;
    int b;


    DeepCopy(){
    }

    public DeepCopy(int a,int b){
        this.a= a;
        this.b=b;
    }

    public Object clone() throws CloneNotSupportedException{
        return super.clone();
    }

    public void showData(){
        System.out.println("From Deep Copy : "+a +","+ b);
    }
}
