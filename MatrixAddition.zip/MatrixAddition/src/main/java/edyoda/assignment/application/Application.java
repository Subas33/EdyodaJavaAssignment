package edyoda.assignment.application;

import java.util.Scanner;

public class Application {

    public int[][] add(int row1, int col1, int row2, int col2,int[][] mat1, int[][] mat2){
        int[][] result = new int[row1][col1];
        for(int i=0;i<row1;i++){
            for(int j=0;j<col2;j++){
                for(int k=0;k<col1;k++) {
                    result[i][j] = mat1[i][j] + mat2[i][j];
                }
            }
        }
        return result;
    }

    public int[][] getMatrix(int row, int col,Scanner sc){
        int[][] result = new int[row][col];
        for(int i=0;i<row;i++){
            for(int j=0;j<col;j++){
                result[i][j] = sc.nextInt();
            }
        }
        return result;
    }


    public void displayMatrix(int[][] result,int row,int col){
        for(int i=0;i<row;i++){
            for(int j=0;j<col;j++){
                System.out.print(result[i][j]+ " ");
            }
            System.out.println();
        }

    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Application application = new Application();


        System.out.print("Enter number of row of First Matrix: ");
        int mat1Row = sc.nextInt();
        System.out.print("Enter number of Columns of First Matrix : ");
        int mat1Col = sc.nextInt();
        System.out.print("Enter number of row of Second Matrix : ");
        int mat2Row = sc.nextInt();
        System.out.print("Enter number of Columns of Second Matrix : ");
        int mat2Col = sc.nextInt();

        int[][] matrix1 = new int[mat1Row][mat1Col];
        int[][] matrix2 = new int[mat2Row][mat2Col];

        System.out.print("Enter input for First Matrix: ");

        matrix1 = application.getMatrix(mat1Row,mat1Col,sc);

        System.out.print("Enter input for Second Matrix: ");

        matrix2 = application.getMatrix(mat2Row,mat2Col,sc);


        if(mat1Row == mat1Col && mat2Col == mat2Row){
            int[][] result = new int[mat1Row][mat2Col];

            result = application.add(mat1Row,mat1Col,mat2Row,mat2Col,matrix1,matrix2);

            System.out.println("-------------Resultant Matrix-----------------------");

            application.displayMatrix(result,mat1Row,mat2Col);
        }
        else System.out.println("Matrix cannot be Added");


    }
}
