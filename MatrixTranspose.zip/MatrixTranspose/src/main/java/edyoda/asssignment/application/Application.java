package edyoda.asssignment.application;

import java.util.Scanner;

public class Application {

    public int[][] add(int row1, int col1, int row2, int col2,int[][] mat1, int[][] mat2){
        int[][] result = new int[row1][col1];
        for(int i=0;i<row1;i++){
            for(int j=0;j<col2;j++){
                for(int k=0;k<col1;k++) {
                    result[i][j] = mat1[i][j] + mat2[i][j];
                }
            }
        }
        return result;
    }

    public int[][] getMatrix(int row, int col,Scanner sc){
        int[][] result = new int[row][col];
        for(int i=0;i<row;i++){
            for(int j=0;j<col;j++){
                result[i][j] = sc.nextInt();
            }
        }
        return result;
    }


    public void displayMatrix(int[][] result,int row,int col){
        for(int i=0;i<row;i++){
            for(int j=0;j<col;j++){
                System.out.print(result[i][j]+ " ");
            }
            System.out.println();
        }

    }

    public int[][] transposeMatrix(int[][] matrix,int row, int col){
        int[][] result = new int[row][col];
        for(int i=0;i<row;i++){
            for(int j=0;j<col;j++){
                result[i][j] = matrix[j][i];
            }

        }
        return result;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Application application = new Application();


        System.out.print("Enter number of row of Matrix: ");
        int mat1Row = sc.nextInt();
        System.out.print("Enter number of Columns of Matrix : ");
        int mat1Col = sc.nextInt();

        int[][] matrix1 = new int[mat1Row][mat1Col];


        System.out.print("Enter input for Matrix: ");

        matrix1 = application.getMatrix(mat1Row,mat1Col,sc);


        System.out.println("-----------------Actual Matrix-------------");

        application.displayMatrix(matrix1,mat1Row,mat1Col);

        System.out.println("-----------------Transposed Matrix-------------");

        int[][] transpose = new int[mat1Row][mat1Col];

        transpose = application.transposeMatrix(matrix1,mat1Row,mat1Col);

        application.displayMatrix(transpose,mat1Row,mat1Col);


    }
}

