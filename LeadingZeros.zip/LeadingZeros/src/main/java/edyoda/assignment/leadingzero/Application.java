package edyoda.assignment.leadingzero;

import java.util.Scanner;

public class Application {

    public String removeZeros(String str){
        char[] stringArray = str.toCharArray();
        String result = "";
        int index=0;
        for(int i=0;i<stringArray.length;i++){
            char c = stringArray[i];
            if(Integer.parseInt(String.valueOf(c))==0){
                index = i;
            }
            else break;
        }

        for(int i=index+1;i<stringArray.length;i++){
            result+=stringArray[i];
        }

        return result;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Application application = new Application();

        System.out.println("--------------------Simple Method------------------");
        System.out.println();
        System.out.print("Enter your input with Leading Zeros as Long Integer : ");
        Long input = sc.nextLong();
        System.out.println();
        System.out.println("---------------------Result (Simple)-----------------");
        System.out.println();
        System.out.println(input);
        System.out.println();
        System.out.print("Enter your input with Leading Zeros as String : ");
        String strInput = sc.next();
        System.out.println();
        System.out.println("---------------------Result-------------------");
        System.out.println();

        System.out.println(application.removeZeros(strInput));
    }
}
