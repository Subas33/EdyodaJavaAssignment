package edyoda.assignment.Abstract;

public abstract class Parent {

    public abstract void message();
}
