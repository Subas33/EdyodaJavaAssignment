package edyoda.assignment.Program;

import edyoda.assignment.Abstract.Parent;

public class ClassB extends Parent {

    public void message(){
        System.out.println("This is Second Subclass");
    }
}
