package edyoda.assignment.Program;

public class Main {

    public static void main(String[] args) {
        ClassB Two = new ClassB();
        ClassA One = new ClassA();

        One.message();
        Two.message();
    }
}
