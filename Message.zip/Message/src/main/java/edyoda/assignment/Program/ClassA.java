package edyoda.assignment.Program;

import edyoda.assignment.Abstract.Parent;

public class ClassA extends Parent{

    public void message(){
        System.out.println("This is first Subclass");
    }
}
