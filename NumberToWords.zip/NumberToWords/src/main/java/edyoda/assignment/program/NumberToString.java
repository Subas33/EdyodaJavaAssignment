package edyoda.assignment.program;

import java.util.*;
import java.io.*;
import java.lang.String;

public class NumberToString {

    static void convertToWords(char[] num)
    {
        int len = num.length;


        if (len == 0) {
            System.out.println("Empty string");
            return;
        }
        if (len > 4) {
            System.out.println("Length more than 4 is not supported!!  Please enter less than 4");
            return;
        }


        String[] single_digits = new String[] {
                "Zero", "One", "Two", "Three", "Four",
                "Five", "Six", "Seven", "Eight", "Nine"
        };


        String[] two_digits = new String[] {
                "",		 "Ten",	 "Eleven", "Twelve",
                "Thirteen", "Fourteen", "Fifteen", "Sixteen",
                "Seventeen", "Eighteen", "Nineteen"
        };


        String[] tens_multiple = new String[] {
                "",	 "",	 "Twenty", "Thirty", "Forty",
                "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"
        };

        String[] tens_power
                = new String[] { "Hundred", "Thousand" };

        System.out.print(String.valueOf(num) + ": ");


        if (len == 1) {
            System.out.println(single_digits[num[0] - '0']);
            return;
        }


        int x = 0;
        while (x < num.length) {


            if (len >= 3) {
                if (num[x] - '0' != 0) {
                    System.out.print(
                            single_digits[num[x] - '0'] + " ");
                    System.out.print(tens_power[len - 3]
                            + " ");

                }
                --len;
            }


            else {

                if (num[x] - '0' == 1) {

                    int sum = num[x] -'0' + num[x + 1] - '0';
                    System.out.println(two_digits[sum]);
                    return;
                }


                else if (num[x] - '0' == 2
                        && num[x + 1] - '0' == 0) {
                    System.out.println("twenty");
                    return;
                }


                else {
                    int i = (num[x] - '0');
                    if (i > 0)
                        System.out.print(tens_multiple[i]
                                + " ");
                    else
                        System.out.print("");
                    ++x;
                    if (num[x] - '0' != 0)
                        System.out.println(
                                single_digits[num[x] - '0']);
                }
            }
            ++x;
        }
    }

    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);

        System.out.print("Enter Number: ");
        char[] input = scan.next().toCharArray();
        char[] Test = "12".toCharArray();
        convertToWords(input);
    }
}
