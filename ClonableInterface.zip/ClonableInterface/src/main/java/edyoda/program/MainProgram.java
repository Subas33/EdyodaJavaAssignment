package edyoda.program;

import  java.lang.Cloneable;


public class MainProgram implements Cloneable {

    String name;

    public MainProgram(){

    }

    public MainProgram(String name){
        this.name = name;
    }

    public static void main(String[] args) throws CloneNotSupportedException{

        MainProgram sol = new MainProgram("Subash");

        MainProgram clonedObject = (MainProgram)sol.clone();

        System.out.println("ClonedObject's data: "+ clonedObject.name);

    }

    protected Object clone() throws CloneNotSupportedException{
        return super.clone();
    }

}
